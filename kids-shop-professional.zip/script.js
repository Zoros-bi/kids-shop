const symbols = ['🍎', '🐶', '🚗', '🎈', '🍎', '🐶', '🚗', '🎈'];
let shuffled = symbols.sort(() => 0.5 - Math.random());
let first = null, second = null;

const gameGrid = document.getElementById("memory-game");

shuffled.forEach((symbol) => {
  const card = document.createElement("div");
  card.className = "card";
  card.dataset.symbol = symbol;
  card.innerText = "❓";
  card.onclick = () => {
    if (card.innerText === "❓") {
      card.innerText = symbol;
      if (!first) {
        first = card;
      } else {
        second = card;
        if (first.dataset.symbol === second.dataset.symbol) {
          first = second = null;
        } else {
          setTimeout(() => {
            first.innerText = second.innerText = "❓";
            first = second = null;
          }, 1000);
        }
      }
    }
  };
  gameGrid.appendChild(card);
});
